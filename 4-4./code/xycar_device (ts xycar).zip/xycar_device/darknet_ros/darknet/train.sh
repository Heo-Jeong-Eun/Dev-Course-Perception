#!/bin/bash

./darknet detector train custom_train/obj.data cfg/yolov2-tiny.cfg pretrainned/darknet19_448.conv.23 -dont_show
